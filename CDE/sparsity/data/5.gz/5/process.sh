#!/bin/bash

sparse_data_processing() {
  for i in ./*.sparsity.txt
    do
     cut -f1 -d ' ' $i > ./$i.stmp
     cut -f2 -d ' ' $i > ./$i.ptmp  
     #-f says which field you want to extract, -d says what is the field delimeter that is used in the input file 
    done
  paste ./*.stmp > sparsity.all
  paste ./*.ptmp > problems.all
  rm *.stmp *.ptmp
  
}
sparse_data_processing
